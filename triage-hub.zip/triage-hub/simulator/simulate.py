#!/usr/bin/env python3
"""
Edge-device fleet simulator for the Triage Hub.

Posts batches of telemetry to the ingest webhook the way a factory gateway
would: steady noisy signals, occasional drift incidents that cross
thresholds, sudden spikes, a device whose clock loses NTP sync, and the odd
malformed payload so validation has something to reject.

Standard library only. Python 3.9+.

    python3 simulator/simulate.py                       # 1 batch/s forever
    python3 simulator/simulate.py --rate 4 --seed 7     # faster, reproducible
    python3 simulator/simulate.py --burst critical      # force an incident now
"""
from __future__ import annotations

import argparse
import json
import random
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

FLEET: dict[str, list[str]] = {
    "press-line-01": ["temperature", "vibration", "pressure"],
    "press-line-02": ["temperature", "vibration", "pressure"],
    "cnc-07": ["temperature", "vibration"],
    "compressor-a": ["pressure", "temperature"],
    "cold-room-3": ["temperature", "humidity"],
    "paint-booth-1": ["humidity", "temperature"],
}

# mean, noise (std dev), drift step per tick during an incident
BASELINE = {
    "temperature": (48.0, 0.8, 1.6),
    "vibration": (3.2, 0.25, 0.35),
    "pressure": (5.5, 0.12, 0.22),
    "humidity": (45.0, 1.2, 2.4),
}
OVERRIDES = {("cold-room-3", "temperature"): 3.0}

MALFORMED = [
    {"deviceId": "press-line-01", "sensor": "temperature", "value": "NaN"},
    {"deviceId": "cold-room-3", "sensor": "temperature", "value": 37.5, "unit": "°F"},
    {"device": "cnc-07", "sensor": "vibration", "value": 2.9},
    {"deviceId": "unknown sensor!", "sensor": "radiation", "value": 1},
]


@dataclass
class Channel:
    device_id: str
    sensor: str
    home: float
    level: float = field(init=False)
    drift_ticks: int = 0
    drift_dir: int = 1

    def __post_init__(self) -> None:
        self.level = self.home

    def step(self, rnd: random.Random) -> float:
        _, noise, drift = BASELINE[self.sensor]
        if self.drift_ticks == 0 and rnd.random() < 0.0015:
            self.start_incident(rnd)
        if self.drift_ticks > 0:
            self.level += self.drift_dir * drift * (0.6 + rnd.random())
            self.drift_ticks -= 1
        else:
            self.level += (self.home - self.level) * 0.15  # relax back to normal

        value = self.level + rnd.gauss(0, noise)
        if rnd.random() < 0.003:  # one-off spike
            value += rnd.choice((-1, 1)) * noise * rnd.uniform(10, 20)
        if self.sensor == "vibration":
            value = max(0.05, value)
        elif self.sensor == "humidity":
            value = min(100.0, max(0.0, value))
        return round(value, 2)

    def start_incident(self, rnd: random.Random, ticks: int | None = None) -> None:
        self.drift_ticks = ticks or rnd.randint(12, 30)
        self.drift_dir = -1 if self.sensor == "pressure" and rnd.random() < 0.5 else 1


def iso(dt: datetime) -> str:
    return dt.isoformat(timespec="milliseconds").replace("+00:00", "Z")


class Fleet:
    def __init__(self, seed: int | None) -> None:
        self.rnd = random.Random(seed)
        self.channels = [
            Channel(dev, s, OVERRIDES.get((dev, s), BASELINE[s][0]))
            for dev, sensors in FLEET.items()
            for s in sensors
        ]

    def tick(self) -> list[dict]:
        now = datetime.now(timezone.utc)
        batch: list[dict] = []
        for ch in self.channels:
            ts = now
            if ch.device_id == "cnc-07" and self.rnd.random() < 0.01:
                ts = now - timedelta(minutes=9)  # clock drifted
            batch.append({
                "deviceId": ch.device_id,
                "sensor": ch.sensor,
                "value": ch.step(self.rnd),
                "ts": iso(ts),
                "meta": {"fw": "2.4.1", "gateway": "gw-gbg-1"},
            })
        if self.rnd.random() < 0.03:
            batch.append(self.rnd.choice(MALFORMED))
        return batch

    def force_incident(self) -> Channel:
        ch = self.rnd.choice(self.channels)
        ch.start_incident(self.rnd, ticks=40)
        return ch


def post(url: str, api_key: str, batch: list[dict]) -> dict:
    req = urllib.request.Request(
        url,
        data=json.dumps({"readings": batch}).encode(),
        headers={"content-type": "application/json", "x-api-key": api_key},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as res:
            return json.load(res)
    except urllib.error.HTTPError as e:  # 422 = whole batch rejected; still JSON
        return json.load(e)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--url", default="http://localhost:4000/api/ingest")
    p.add_argument("--api-key", default="dev-ingest-key")
    p.add_argument("--rate", type=float, default=1.0, help="batches per second")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--ticks", type=int, default=0, help="stop after N batches (0 = run forever)")
    p.add_argument("--burst", choices=["critical"], help="start a drift incident immediately")
    args = p.parse_args()

    fleet = Fleet(args.seed)
    if args.burst:
        ch = fleet.force_incident()
        print(f"Forced incident on {ch.device_id}/{ch.sensor}")

    sent = rejected = 0
    tick = 0
    interval = 1 / args.rate
    print(f"Posting to {args.url} at {args.rate} batch/s. Ctrl+C to stop.")
    try:
        while args.ticks == 0 or tick < args.ticks:
            started = time.monotonic()
            try:
                result = post(args.url, args.api_key, fleet.tick())
            except (urllib.error.URLError, ConnectionError) as e:
                print(f"  ! ingest unreachable ({e}); retrying", file=sys.stderr)
                time.sleep(2)
                continue
            sent += result.get("accepted", 0)
            for r in result.get("rejected", []):
                rejected += 1
                print(f"  ✗ rejected: {'; '.join(r['errors'])}")
            tick += 1
            if tick % 10 == 0:
                print(f"  {tick} batches · {sent} accepted · {rejected} rejected")
            time.sleep(max(0.0, interval - (time.monotonic() - started)))
    except KeyboardInterrupt:
        pass
    print(f"Done: {sent} readings accepted, {rejected} rejected.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
