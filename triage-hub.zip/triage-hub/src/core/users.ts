import type { User } from './types';

// Demo identities. A real deployment would swap this for SSO / JWT; the server
// only depends on `userFromToken`, so that swap stays local.
export const DEMO_USERS: User[] = [
  { id: 'sara', name: 'Sara', role: 'viewer' },
  { id: 'erik', name: 'Erik', role: 'operator' },
  { id: 'amira', name: 'Amira', role: 'admin' },
];

export function tokenFor(user: User): string {
  return `demo.${user.id}`;
}

export function userFromToken(token: string | undefined | null): User | undefined {
  if (!token?.startsWith('demo.')) return undefined;
  return DEMO_USERS.find((u) => u.id === token.slice(5));
}
