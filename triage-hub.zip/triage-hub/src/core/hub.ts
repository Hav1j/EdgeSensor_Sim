import { evaluate, HISTORY_WINDOW, maxSeverity, THRESHOLDS } from './rules';
import type {
  Alert,
  AlertAction,
  AlertQuery,
  Device,
  HubEvent,
  IngestResult,
  Kpis,
  Reading,
  ReadingQuery,
  User,
} from './types';
import { readingInputSchema, splitIngestBody, formatIssues } from './validation';
import { can, checkTransition } from './workflow';

export class HubError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
  ) {
    super(message);
  }
}

export interface AuditEntry {
  at: number;
  by: string;
  role: User['role'];
  action: string;
  target: string;
  detail?: string;
}

export interface HubOptions {
  now?: () => number;
  maxReadings?: number;
  /** A device counts as online if it reported within this window. */
  onlineWindowMs?: number;
}

type Listener = (e: HubEvent) => void;

/**
 * The whole backend domain in one framework-free class: ingest, anomaly
 * evaluation, alert grouping, the triage workflow, RBAC checks and KPIs.
 * The Express server wraps it in HTTP; the browser demo runs it directly.
 */
export class TriageHub {
  private readonly now: () => number;
  private readonly maxReadings: number;
  private readonly onlineWindowMs: number;

  private readings: Reading[] = [];
  private readingById = new Map<string, Reading>();
  private history = new Map<string, number[]>();
  private alerts = new Map<string, Alert>();
  private activeAlertByKey = new Map<string, string>();
  private devices = new Map<string, Device>();
  private audit: AuditEntry[] = [];
  private listeners = new Set<Listener>();
  private rejectedPayloads = 0;
  private seq = 0;

  constructor(opts: HubOptions = {}) {
    this.now = opts.now ?? Date.now;
    this.maxReadings = opts.maxReadings ?? 5000;
    this.onlineWindowMs = opts.onlineWindowMs ?? 30_000;
  }

  // --- events ---------------------------------------------------------------

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit(e: HubEvent) {
    for (const fn of this.listeners) fn(e);
  }

  private id(prefix: string) {
    return `${prefix}_${(++this.seq).toString(36).padStart(5, '0')}`;
  }

  // --- ingest ---------------------------------------------------------------

  ingest(body: unknown): IngestResult {
    const split = splitIngestBody(body);
    if ('error' in split) {
      this.rejectedPayloads++;
      throw new HubError(400, 'bad_request', split.error);
    }

    const result: IngestResult = { accepted: 0, rejected: [] };
    split.items.forEach((item, index) => {
      const parsed = readingInputSchema.safeParse(item);
      if (!parsed.success) {
        this.rejectedPayloads++;
        result.rejected.push({ index, errors: formatIssues(parsed.error) });
        return;
      }
      this.addReading(parsed.data, item);
      result.accepted++;
    });
    return result;
  }

  private addReading(input: ReturnType<typeof readingInputSchema.parse>, raw: unknown) {
    const receivedAt = this.now();
    const ts = input.ts ?? receivedAt;
    const key = `${input.deviceId}|${input.sensor}`;
    const hist = this.history.get(key) ?? [];

    const { severity, flags } = evaluate(input.sensor, input.value, ts, receivedAt, hist);

    hist.push(input.value);
    if (hist.length > HISTORY_WINDOW) hist.shift();
    this.history.set(key, hist);

    const reading: Reading = {
      id: this.id('r'),
      deviceId: input.deviceId,
      sensor: input.sensor,
      value: input.value,
      unit: THRESHOLDS[input.sensor].unit,
      ts,
      receivedAt,
      severity,
      flags,
      payload: raw,
    };

    this.readings.push(reading);
    this.readingById.set(reading.id, reading);
    while (this.readings.length > this.maxReadings) {
      const old = this.readings.shift()!;
      this.readingById.delete(old.id);
    }

    const device = this.devices.get(input.deviceId) ?? {
      id: input.deviceId,
      lastSeen: 0,
      muted: false,
      readingCount: 0,
    };
    device.lastSeen = receivedAt;
    device.readingCount++;
    this.devices.set(device.id, device);

    this.emit({ type: 'reading', reading });
    this.emit({ type: 'device', device: { ...device } });

    if (severity !== 'ok' && !device.muted) this.raiseAlert(reading, key);
  }

  /** Fold an anomalous reading into the active alert for its device + sensor, or open a new one. */
  private raiseAlert(reading: Reading, key: string) {
    const sev = reading.severity as Alert['severity'];
    const activeId = this.activeAlertByKey.get(key);
    const existing = activeId ? this.alerts.get(activeId) : undefined;

    if (existing) {
      existing.count++;
      existing.lastSeen = reading.receivedAt;
      existing.readingIds.push(reading.id);
      if (existing.readingIds.length > 50) existing.readingIds.shift();
      if (existing.severity !== maxSeverity(existing.severity, sev)) {
        existing.severity = sev;
        existing.title = alertTitle(reading);
        existing.history.push({ at: reading.receivedAt, by: 'system', action: 'updated', note: `Severity raised to ${sev}` });
      }
      this.emit({ type: 'alert', alert: structuredClone(existing) });
      return;
    }

    const alert: Alert = {
      id: this.id('a'),
      deviceId: reading.deviceId,
      sensor: reading.sensor,
      severity: sev,
      status: 'open',
      title: alertTitle(reading),
      firstSeen: reading.receivedAt,
      lastSeen: reading.receivedAt,
      count: 1,
      readingIds: [reading.id],
      history: [{ at: reading.receivedAt, by: 'system', action: 'created', to: 'open', note: reading.flags[0]?.message }],
    };
    this.alerts.set(alert.id, alert);
    this.activeAlertByKey.set(key, alert.id);
    this.emit({ type: 'alert', alert: structuredClone(alert) });
  }

  // --- reads ----------------------------------------------------------------

  listReadings(query: ReadingQuery = {}): Reading[] {
    const q = normalizeQ(query.q);
    const limit = query.limit ?? 200;
    const out: Reading[] = [];
    for (let i = this.readings.length - 1; i >= 0 && out.length < limit; i--) {
      const r = this.readings[i]!;
      if (readingMatches(r, query, q)) out.push(r);
    }
    return out;
  }

  getReading(id: string): Reading {
    const r = this.readingById.get(id);
    if (!r) throw new HubError(404, 'not_found', `Reading ${id} not found (it may have aged out)`);
    return r;
  }

  listAlerts(query: AlertQuery = {}): Alert[] {
    const q = normalizeQ(query.q);
    return sortAlerts([...this.alerts.values()].filter((a) => alertMatches(a, query, q))).map((a) => structuredClone(a));
  }

  getAlert(id: string): Alert {
    const a = this.alerts.get(id);
    if (!a) throw new HubError(404, 'not_found', `Alert ${id} not found`);
    return structuredClone(a);
  }

  listDevices(): Device[] {
    return [...this.devices.values()].sort((a, b) => a.id.localeCompare(b.id)).map((d) => ({ ...d }));
  }

  getAudit(user: User): AuditEntry[] {
    if (!can(user.role, 'audit:read')) throw new HubError(403, 'forbidden', 'Only admins can read the audit log');
    return [...this.audit].reverse();
  }

  // --- writes ---------------------------------------------------------------

  transition(alertId: string, user: User, action: AlertAction, note?: string): Alert {
    const alert = this.alerts.get(alertId);
    if (!alert) throw new HubError(404, 'not_found', `Alert ${alertId} not found`);

    const check = checkTransition(user.role, alert.status, action, note);
    if (!check.ok) {
      const status = check.code === 'forbidden' ? 403 : check.code === 'invalid_transition' ? 409 : 422;
      throw new HubError(status, check.code, check.message);
    }

    const at = this.now();
    const from = alert.status;
    alert.status = check.to;
    alert.history.push({ at, by: user.name, action, from, to: check.to, note: note?.trim() || undefined });

    if ((action === 'acknowledge' || action === 'escalate') && alert.acknowledgedAt === undefined) {
      alert.acknowledgedAt = at;
    }
    const key = `${alert.deviceId}|${alert.sensor}`;
    if (check.to === 'resolved') {
      alert.resolvedAt = at;
      if (this.activeAlertByKey.get(key) === alert.id) this.activeAlertByKey.delete(key);
    }
    if (action === 'reopen') {
      alert.resolvedAt = undefined;
      // If a newer alert has opened for the same source meanwhile, leave that one active.
      if (!this.activeAlertByKey.has(key)) this.activeAlertByKey.set(key, alert.id);
    }

    this.log(user, action, alert.id, note);
    this.emit({ type: 'alert', alert: structuredClone(alert) });
    return structuredClone(alert);
  }

  assign(alertId: string, user: User, assignee: string | null): Alert {
    if (!can(user.role, 'alerts:triage')) throw new HubError(403, 'forbidden', `A ${user.role} can't assign alerts.`);
    const alert = this.alerts.get(alertId);
    if (!alert) throw new HubError(404, 'not_found', `Alert ${alertId} not found`);
    if (alert.status === 'resolved') throw new HubError(409, 'invalid_transition', "Can't reassign a resolved alert.");
    alert.assignee = assignee?.trim() || undefined;
    alert.history.push({ at: this.now(), by: user.name, action: 'updated', note: alert.assignee ? `Assigned to ${alert.assignee}` : 'Unassigned' });
    this.log(user, 'assign', alert.id, alert.assignee ?? 'nobody');
    this.emit({ type: 'alert', alert: structuredClone(alert) });
    return structuredClone(alert);
  }

  setMuted(deviceId: string, user: User, muted: boolean): Device {
    if (!can(user.role, 'devices:mute')) throw new HubError(403, 'forbidden', 'Only admins can mute devices.');
    const device = this.devices.get(deviceId);
    if (!device) throw new HubError(404, 'not_found', `Device ${deviceId} not found`);
    device.muted = muted;
    this.log(user, muted ? 'mute' : 'unmute', deviceId);
    this.emit({ type: 'device', device: { ...device } });
    return { ...device };
  }

  private log(user: User, action: string, target: string, detail?: string) {
    this.audit.push({ at: this.now(), by: user.name, role: user.role, action, target, detail: detail?.trim() || undefined });
    if (this.audit.length > 1000) this.audit.shift();
  }

  // --- KPIs -----------------------------------------------------------------

  /** Push a fresh KPI snapshot to subscribers. Called on a timer, not per reading. */
  publishKpis(): void {
    this.emit({ type: 'kpis', kpis: this.kpis() });
  }

  kpis(): Kpis {
    const now = this.now();
    const bucketMs = 10_000;
    const buckets = 30;
    const throughput = new Array<number>(buckets).fill(0);
    let lastMin = 0;
    let lastMinAnomalous = 0;

    for (let i = this.readings.length - 1; i >= 0; i--) {
      const r = this.readings[i]!;
      const age = now - r.receivedAt;
      if (age >= bucketMs * buckets) break;
      throughput[buckets - 1 - Math.floor(age / bucketMs)]!++;
      if (age < 60_000) {
        lastMin++;
        if (r.severity !== 'ok') lastMinAnomalous++;
      }
    }

    const openBySeverity = { warning: 0, critical: 0 };
    let unacknowledged = 0;
    let escalated = 0;
    let ackSum = 0;
    let ackN = 0;
    for (const a of this.alerts.values()) {
      if (a.status !== 'resolved') openBySeverity[a.severity]++;
      if (a.status === 'open') unacknowledged++;
      if (a.status === 'escalated') escalated++;
      if (a.acknowledgedAt !== undefined) {
        ackSum += a.acknowledgedAt - a.firstSeen;
        ackN++;
      }
    }

    const devices = [...this.devices.values()];
    return {
      readingsPerMin: lastMin,
      anomalyRate: lastMin ? lastMinAnomalous / lastMin : 0,
      openBySeverity,
      unacknowledged,
      escalated,
      devicesOnline: devices.filter((d) => now - d.lastSeen < this.onlineWindowMs).length,
      devicesTotal: devices.length,
      rejectedPayloads: this.rejectedPayloads,
      mttaMs: ackN ? ackSum / ackN : null,
      throughput,
    };
  }
}

function alertTitle(r: Reading): string {
  const flag = r.flags.find((f) => f.code !== 'spike' && f.code !== 'clock_skew') ?? r.flags[0];
  const what =
    flag?.code === 'spike' ? 'sudden change' : flag?.code === 'clock_skew' ? 'clock skew' : flag?.code.startsWith('below') ? 'low' : 'high';
  return `${r.sensor[0]!.toUpperCase()}${r.sensor.slice(1)} ${what} on ${r.deviceId}`;
}

// --- filtering (shared with the React app so live views filter identically) ---

export const normalizeQ = (q?: string) => q?.trim().toLowerCase() || undefined;

export function readingMatches(r: Reading, query: ReadingQuery, q = normalizeQ(query.q)): boolean {
  if (query.severity === 'anomalous' ? r.severity === 'ok' : query.severity && r.severity !== query.severity) return false;
  if (query.sensor && r.sensor !== query.sensor) return false;
  if (query.deviceId && r.deviceId !== query.deviceId) return false;
  if (!q) return true;
  if (`${r.id} ${r.deviceId} ${r.sensor} ${r.severity}`.toLowerCase().includes(q)) return true;
  if (r.flags.some((f) => f.message.toLowerCase().includes(q) || f.code.includes(q))) return true;
  return JSON.stringify(r.payload).toLowerCase().includes(q);
}

export function alertMatches(a: Alert, query: AlertQuery, q = normalizeQ(query.q)): boolean {
  if (query.status === 'active' ? a.status === 'resolved' : query.status && a.status !== query.status) return false;
  if (query.severity && a.severity !== query.severity) return false;
  if (q && !`${a.id} ${a.deviceId} ${a.sensor} ${a.title} ${a.assignee ?? ''}`.toLowerCase().includes(q)) return false;
  return true;
}

/** Critical first, then most recently active. */
export function sortAlerts(alerts: Alert[]): Alert[] {
  const rank = (a: Alert) => (a.severity === 'critical' ? 1 : 0);
  return alerts.sort((a, b) => rank(b) - rank(a) || b.lastSeen - a.lastSeen);
}
