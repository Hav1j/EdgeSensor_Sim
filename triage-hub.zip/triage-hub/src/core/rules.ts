import type { Flag, SensorKind, Severity } from './types';

// Anomaly detection is deliberately boring: fixed thresholds per sensor plus a
// rolling z-score for sudden spikes. Every flag can be explained to an
// operator in one sentence, which matters more in triage than cleverness.

export interface Thresholds {
  unit: string;
  warnHigh: number;
  critHigh: number;
  warnLow?: number;
  critLow?: number;
}

export const THRESHOLDS: Record<SensorKind, Thresholds> = {
  temperature: { unit: '°C', warnHigh: 70, critHigh: 85, warnLow: -10, critLow: -25 },
  vibration: { unit: 'mm/s', warnHigh: 7.1, critHigh: 11.2 },
  pressure: { unit: 'bar', warnHigh: 8, critHigh: 10, warnLow: 1, critLow: 0.5 },
  humidity: { unit: '%', warnHigh: 80, critHigh: 92, warnLow: 15 },
};

/** Values outside these ranges are physically impossible and get rejected at ingest. */
export const PHYSICAL_RANGE: Partial<Record<SensorKind, [number, number]>> = {
  vibration: [0, 100],
  humidity: [0, 100],
  pressure: [0, 1000],
  temperature: [-273.15, 2000],
};

export const SPIKE_Z = 4;
export const SPIKE_MIN_SAMPLES = 10;
export const HISTORY_WINDOW = 30;
export const MAX_CLOCK_SKEW_MS = 5 * 60_000;

const RANK: Record<Severity, number> = { ok: 0, warning: 1, critical: 2 };

export function maxSeverity(a: Severity, b: Severity): Severity {
  return RANK[a] >= RANK[b] ? a : b;
}

export function mean(xs: number[]): number {
  return xs.reduce((s, x) => s + x, 0) / xs.length;
}

export function stdDev(xs: number[]): number {
  const m = mean(xs);
  return Math.sqrt(xs.reduce((s, x) => s + (x - m) ** 2, 0) / xs.length);
}

const fmt = (n: number) => (Math.abs(n) >= 100 ? n.toFixed(0) : n.toFixed(1));

/**
 * Evaluate one reading.
 * @param history recent values for the same device + sensor, oldest first,
 *                not including this reading.
 */
export function evaluate(
  sensor: SensorKind,
  value: number,
  ts: number,
  receivedAt: number,
  history: readonly number[],
): { severity: Severity; flags: Flag[] } {
  const t = THRESHOLDS[sensor];
  const flags: Flag[] = [];
  let severity: Severity = 'ok';

  if (value >= t.critHigh) {
    flags.push({ code: 'above_critical', message: `${fmt(value)} ${t.unit} is at or above critical (${t.critHigh})` });
    severity = 'critical';
  } else if (value >= t.warnHigh) {
    flags.push({ code: 'above_warning', message: `${fmt(value)} ${t.unit} is at or above warning (${t.warnHigh})` });
    severity = 'warning';
  }

  if (t.critLow !== undefined && value <= t.critLow) {
    flags.push({ code: 'below_critical', message: `${fmt(value)} ${t.unit} is at or below critical (${t.critLow})` });
    severity = maxSeverity(severity, 'critical');
  } else if (t.warnLow !== undefined && value <= t.warnLow) {
    flags.push({ code: 'below_warning', message: `${fmt(value)} ${t.unit} is at or below warning (${t.warnLow})` });
    severity = maxSeverity(severity, 'warning');
  }

  if (history.length >= SPIKE_MIN_SAMPLES) {
    const m = mean(history as number[]);
    // Floor the deviation so a perfectly flat signal doesn't flag every tiny wobble.
    const sd = Math.max(stdDev(history as number[]), Math.abs(m) * 0.01, 1e-6);
    const z = (value - m) / sd;
    if (Math.abs(z) >= SPIKE_Z) {
      flags.push({
        code: 'spike',
        message: `Sudden ${z > 0 ? 'jump' : 'drop'}: ${fmt(value)} vs recent mean ${fmt(m)} (z = ${z.toFixed(1)})`,
      });
      severity = maxSeverity(severity, 'warning');
    }
  }

  const skew = ts - receivedAt;
  if (Math.abs(skew) > MAX_CLOCK_SKEW_MS) {
    flags.push({
      code: 'clock_skew',
      message: `Device clock is ${Math.round(Math.abs(skew) / 60_000)} min ${skew > 0 ? 'ahead' : 'behind'}`,
    });
    severity = maxSeverity(severity, 'warning');
  }

  return { severity, flags };
}
