import type { AlertAction, AlertStatus, Role } from './types';

// --- Permissions (RBAC) -----------------------------------------------------

export type Permission =
  | 'readings:read'
  | 'alerts:read'
  | 'alerts:triage' // acknowledge / escalate / resolve / assign
  | 'alerts:reopen'
  | 'devices:mute'
  | 'audit:read';

const ROLE_PERMISSIONS: Record<Role, readonly Permission[]> = {
  viewer: ['readings:read', 'alerts:read'],
  operator: ['readings:read', 'alerts:read', 'alerts:triage'],
  admin: ['readings:read', 'alerts:read', 'alerts:triage', 'alerts:reopen', 'devices:mute', 'audit:read'],
};

export function can(role: Role, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role].includes(permission);
}

// --- Alert state machine ------------------------------------------------------
//
//   open ──acknowledge──▶ acknowledged ──resolve──▶ resolved
//     │                       │                        │
//     └──escalate──▶ escalated ◀──escalate─┘            │
//                       └──────resolve────────▶         │
//   resolved ──reopen (admin)──▶ open ◀──────────────────┘

interface TransitionRule {
  from: readonly AlertStatus[];
  to: AlertStatus;
  permission: Permission;
  noteRequired: boolean;
}

export const TRANSITIONS: Record<AlertAction, TransitionRule> = {
  acknowledge: { from: ['open'], to: 'acknowledged', permission: 'alerts:triage', noteRequired: false },
  escalate: { from: ['open', 'acknowledged'], to: 'escalated', permission: 'alerts:triage', noteRequired: true },
  resolve: { from: ['acknowledged', 'escalated'], to: 'resolved', permission: 'alerts:triage', noteRequired: true },
  reopen: { from: ['resolved'], to: 'open', permission: 'alerts:reopen', noteRequired: true },
};

export type TransitionCheck =
  | { ok: true; to: AlertStatus }
  | { ok: false; code: 'forbidden' | 'invalid_transition' | 'note_required'; message: string };

export function checkTransition(
  role: Role,
  status: AlertStatus,
  action: AlertAction,
  note?: string,
): TransitionCheck {
  const rule = TRANSITIONS[action];
  if (!can(role, rule.permission)) {
    return { ok: false, code: 'forbidden', message: `A ${role} can't ${action} alerts.` };
  }
  if (!rule.from.includes(status)) {
    return { ok: false, code: 'invalid_transition', message: `Can't ${action} an alert that is ${status}.` };
  }
  if (rule.noteRequired && !note?.trim()) {
    return { ok: false, code: 'note_required', message: `A note is required to ${action}.` };
  }
  return { ok: true, to: rule.to };
}

/** Actions this role could take on an alert in this status (for the UI). */
export function availableActions(role: Role, status: AlertStatus): AlertAction[] {
  return (Object.keys(TRANSITIONS) as AlertAction[]).filter((a) => {
    const r = TRANSITIONS[a];
    return r.from.includes(status) && can(role, r.permission);
  });
}
