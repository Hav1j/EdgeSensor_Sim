// Shared domain types. Used by the Node server, the React app and the tests.

export const SENSOR_KINDS = ['temperature', 'vibration', 'pressure', 'humidity'] as const;
export type SensorKind = (typeof SENSOR_KINDS)[number];

export const SEVERITIES = ['ok', 'warning', 'critical'] as const;
export type Severity = (typeof SEVERITIES)[number];

export const ROLES = ['viewer', 'operator', 'admin'] as const;
export type Role = (typeof ROLES)[number];

export const ALERT_STATUSES = ['open', 'acknowledged', 'escalated', 'resolved'] as const;
export type AlertStatus = (typeof ALERT_STATUSES)[number];

/** Why a reading was flagged. Every flag is a plain, explainable rule. */
export type FlagCode =
  | 'above_warning'
  | 'above_critical'
  | 'below_warning'
  | 'below_critical'
  | 'spike'
  | 'clock_skew';

export interface Flag {
  code: FlagCode;
  message: string;
}

export interface Reading {
  id: string;
  deviceId: string;
  sensor: SensorKind;
  value: number;
  unit: string;
  /** Device-reported timestamp (ms since epoch). */
  ts: number;
  /** Server receive time (ms since epoch). */
  receivedAt: number;
  severity: Severity;
  flags: Flag[];
  /** The raw payload as it arrived, for the payload inspector. */
  payload: unknown;
}

export interface AlertEvent {
  at: number;
  by: string;
  action: AlertAction | 'created' | 'updated';
  from?: AlertStatus;
  to?: AlertStatus;
  note?: string;
}

export interface Alert {
  id: string;
  deviceId: string;
  sensor: SensorKind;
  severity: Exclude<Severity, 'ok'>;
  status: AlertStatus;
  title: string;
  firstSeen: number;
  lastSeen: number;
  /** Number of anomalous readings folded into this alert. */
  count: number;
  readingIds: string[];
  assignee?: string;
  acknowledgedAt?: number;
  resolvedAt?: number;
  history: AlertEvent[];
}

export type AlertAction = 'acknowledge' | 'escalate' | 'resolve' | 'reopen';

export interface Device {
  id: string;
  lastSeen: number;
  muted: boolean;
  readingCount: number;
}

export interface User {
  id: string;
  name: string;
  role: Role;
}

export interface Kpis {
  readingsPerMin: number;
  anomalyRate: number;
  openBySeverity: Record<'warning' | 'critical', number>;
  unacknowledged: number;
  escalated: number;
  devicesOnline: number;
  devicesTotal: number;
  rejectedPayloads: number;
  /** Mean time to acknowledge, ms. Null until something has been acknowledged. */
  mttaMs: number | null;
  /** Readings per 10 s bucket for the last 5 minutes, oldest first. */
  throughput: number[];
}

export interface IngestResult {
  accepted: number;
  rejected: { index: number; errors: string[] }[];
}

/** Events pushed to clients over the live stream. */
export type HubEvent =
  | { type: 'reading'; reading: Reading }
  | { type: 'alert'; alert: Alert }
  | { type: 'device'; device: Device }
  | { type: 'kpis'; kpis: Kpis };

export interface ReadingQuery {
  q?: string;
  severity?: Severity | 'anomalous';
  sensor?: SensorKind;
  deviceId?: string;
  limit?: number;
}

export interface AlertQuery {
  status?: AlertStatus | 'active';
  severity?: Exclude<Severity, 'ok'>;
  q?: string;
}
