import type { SensorKind } from './types';

// TypeScript twin of simulator/simulate.py, used by the in-browser demo build.
// Produces realistic noisy telemetry with occasional incidents: slow drifts
// past a threshold, sudden spikes, a clock-skewed device and malformed payloads.

export interface SimDevice {
  id: string;
  sensors: SensorKind[];
}

export const FLEET: SimDevice[] = [
  { id: 'press-line-01', sensors: ['temperature', 'vibration', 'pressure'] },
  { id: 'press-line-02', sensors: ['temperature', 'vibration', 'pressure'] },
  { id: 'cnc-07', sensors: ['temperature', 'vibration'] },
  { id: 'compressor-a', sensors: ['pressure', 'temperature'] },
  { id: 'cold-room-3', sensors: ['temperature', 'humidity'] },
  { id: 'paint-booth-1', sensors: ['humidity', 'temperature'] },
];

const BASE: Record<SensorKind, { mean: number; noise: number; drift: number }> = {
  temperature: { mean: 48, noise: 0.8, drift: 1.6 },
  vibration: { mean: 3.2, noise: 0.25, drift: 0.35 },
  pressure: { mean: 5.5, noise: 0.12, drift: 0.22 },
  humidity: { mean: 45, noise: 1.2, drift: 2.4 },
};
const COLD_ROOM_TEMP = 3;

/** Small deterministic PRNG (mulberry32) so demo runs are reproducible. */
export function rng(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t >>> 0) / 4294967296);
  };
}

interface Channel {
  deviceId: string;
  sensor: SensorKind;
  level: number;
  /** Remaining ticks of an ongoing drift incident, and its direction. */
  drift: number;
  driftDir: 1 | -1;
}

export class Simulator {
  private channels: Channel[];
  private rand: () => number;

  constructor(seed = 42, fleet: SimDevice[] = FLEET) {
    this.rand = rng(seed);
    this.channels = fleet.flatMap((d) =>
      d.sensors.map((sensor) => ({
        deviceId: d.id,
        sensor,
        level: d.id === 'cold-room-3' && sensor === 'temperature' ? COLD_ROOM_TEMP : BASE[sensor].mean,
        drift: 0,
        driftDir: 1 as const,
      })),
    );
  }

  private gauss() {
    // Box-Muller
    const u = 1 - this.rand();
    const v = this.rand();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  /** One tick: a batch of payloads, as a device gateway would post them. */
  tick(now = Date.now()): unknown[] {
    const out: unknown[] = [];
    for (const c of this.channels) {
      const b = BASE[c.sensor];
      const home = c.deviceId === 'cold-room-3' && c.sensor === 'temperature' ? COLD_ROOM_TEMP : b.mean;

      if (c.drift === 0 && this.rand() < 0.0015) {
        c.drift = 12 + Math.floor(this.rand() * 18);
        c.driftDir = c.sensor === 'pressure' && this.rand() < 0.5 ? -1 : 1;
      }
      if (c.drift > 0) {
        c.level += c.driftDir * b.drift * (0.6 + this.rand());
        c.drift--;
      } else {
        c.level += (home - c.level) * 0.15; // relax back toward normal
      }

      let value = c.level + this.gauss() * b.noise;
      if (this.rand() < 0.003) value += (this.rand() < 0.5 ? -1 : 1) * b.noise * (10 + this.rand() * 10);

      if (c.sensor === 'vibration') value = Math.max(0.05, value);
      if (c.sensor === 'humidity') value = Math.min(100, Math.max(0, value));

      const payload: Record<string, unknown> = {
        deviceId: c.deviceId,
        sensor: c.sensor,
        value: Math.round(value * 100) / 100,
        ts: new Date(now).toISOString(),
        meta: { fw: '2.4.1', gateway: 'gw-gbg-1' },
      };
      // cnc-07's clock occasionally loses NTP sync.
      if (c.deviceId === 'cnc-07' && this.rand() < 0.01) payload.ts = new Date(now - 9 * 60_000).toISOString();
      out.push(payload);
    }

    // Now and then a gateway sends something broken.
    if (this.rand() < 0.03) {
      const broken = [
        { deviceId: 'press-line-01', sensor: 'temperature', value: 'NaN' },
        { deviceId: 'cold-room-3', sensor: 'temperature', value: 37.5, unit: '°F' },
        { device: 'cnc-07', sensor: 'vibration', value: 2.9 },
        { deviceId: 'unknown sensor!', sensor: 'radiation', value: 1 },
      ];
      out.push(broken[Math.floor(this.rand() * broken.length)]);
    }
    return out;
  }
}
