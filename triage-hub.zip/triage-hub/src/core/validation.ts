import { z } from 'zod';
import { PHYSICAL_RANGE, THRESHOLDS } from './rules';
import { ALERT_STATUSES, SENSOR_KINDS, SEVERITIES, type SensorKind } from './types';

export const MAX_BATCH = 500;

const timestamp = z.union([
  z.number().int().positive(),
  z.iso.datetime({ offset: true }).transform((s) => Date.parse(s)),
]);

export const readingInputSchema = z
  .object({
    deviceId: z
      .string()
      .min(1)
      .max(64)
      .regex(/^[A-Za-z0-9._-]+$/, 'deviceId may only contain letters, digits, dot, dash and underscore'),
    sensor: z.enum(SENSOR_KINDS),
    value: z.number(),
    unit: z.string().optional(),
    ts: timestamp.optional(),
    meta: z.record(z.string(), z.unknown()).optional(),
  })
  .superRefine((r, ctx) => {
    const expected = THRESHOLDS[r.sensor as SensorKind].unit;
    if (r.unit !== undefined && r.unit !== expected) {
      ctx.addIssue({
        code: 'custom',
        path: ['unit'],
        message: `unit for ${r.sensor} must be "${expected}", got "${r.unit}"`,
      });
    }
    const range = PHYSICAL_RANGE[r.sensor as SensorKind];
    if (range && (r.value < range[0] || r.value > range[1])) {
      ctx.addIssue({
        code: 'custom',
        path: ['value'],
        message: `${r.value} is outside the physical range for ${r.sensor} (${range[0]} to ${range[1]})`,
      });
    }
  });

export type ReadingInput = z.infer<typeof readingInputSchema>;

/** Accepts a single reading or `{ readings: [...] }`. */
export function splitIngestBody(body: unknown): { items: unknown[] } | { error: string } {
  if (body && typeof body === 'object' && 'readings' in body) {
    const readings = (body as { readings: unknown }).readings;
    if (!Array.isArray(readings)) return { error: '"readings" must be an array' };
    if (readings.length === 0) return { error: '"readings" is empty' };
    if (readings.length > MAX_BATCH) return { error: `batch too large (max ${MAX_BATCH})` };
    return { items: readings };
  }
  if (body && typeof body === 'object') return { items: [body] };
  return { error: 'body must be a JSON object' };
}

export function formatIssues(error: z.ZodError): string[] {
  return error.issues.map((i) => (i.path.length ? `${i.path.join('.')}: ${i.message}` : i.message));
}

export const transitionSchema = z.object({
  action: z.enum(['acknowledge', 'escalate', 'resolve', 'reopen']),
  note: z.string().max(1000).optional(),
});

export const assignSchema = z.object({
  assignee: z.string().max(64).nullable(),
});

export const readingQuerySchema = z.object({
  q: z.string().max(100).optional(),
  severity: z.enum([...SEVERITIES, 'anomalous']).optional(),
  sensor: z.enum(SENSOR_KINDS).optional(),
  deviceId: z.string().max(64).optional(),
  limit: z.coerce.number().int().min(1).max(1000).optional(),
});

export const alertQuerySchema = z.object({
  status: z.enum([...ALERT_STATUSES, 'active']).optional(),
  severity: z.enum(['warning', 'critical']).optional(),
  q: z.string().max(100).optional(),
});
