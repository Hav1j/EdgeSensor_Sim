import { HubError, TriageHub } from '../core/hub';
import { Simulator } from '../core/simulator';
import type {
  Alert,
  AlertAction,
  AlertQuery,
  Device,
  HubEvent,
  Kpis,
  Reading,
  ReadingQuery,
  User,
} from '../core/types';
import { DEMO_USERS, tokenFor, userFromToken } from '../core/users';
import type { AuditEntry } from '../core/hub';

export type UserWithToken = User & { token: string };
export type ConnectionState = 'connecting' | 'live' | 'reconnecting';

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
  ) {
    super(message);
  }
}

/** Everything the UI needs from a backend. Two implementations below. */
export interface HubClient {
  readonly mode: 'server' | 'demo';
  users(): Promise<UserWithToken[]>;
  setToken(token: string | null): void;
  readings(q?: ReadingQuery): Promise<Reading[]>;
  alerts(q?: AlertQuery): Promise<Alert[]>;
  devices(): Promise<Device[]>;
  kpis(): Promise<Kpis>;
  audit(): Promise<AuditEntry[]>;
  transition(alertId: string, action: AlertAction, note?: string): Promise<Alert>;
  assign(alertId: string, assignee: string | null): Promise<Alert>;
  mute(deviceId: string, muted: boolean): Promise<Device>;
  subscribe(onEvent: (e: HubEvent) => void, onState: (s: ConnectionState) => void): () => void;
}

// --- Talks to the Node server over REST + Server-Sent Events -----------------

export class HttpClient implements HubClient {
  readonly mode = 'server' as const;
  private token: string | null = null;

  setToken(token: string | null) {
    this.token = token;
  }

  private async req<T>(path: string, init: RequestInit = {}): Promise<T> {
    const res = await fetch(`/api${path}`, {
      ...init,
      headers: {
        'content-type': 'application/json',
        ...(this.token ? { authorization: `Bearer ${this.token}` } : {}),
        ...init.headers,
      },
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new ApiError(res.status, body.error ?? 'error', body.message ?? res.statusText);
    return body as T;
  }

  private qs(params: object) {
    const s = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== undefined && v !== '') as [string, string][],
    ).toString();
    return s ? `?${s}` : '';
  }

  users = () => this.req<UserWithToken[]>('/users');
  readings = (q: ReadingQuery = {}) => this.req<Reading[]>(`/readings${this.qs(q)}`);
  alerts = (q: AlertQuery = {}) => this.req<Alert[]>(`/alerts${this.qs(q)}`);
  devices = () => this.req<Device[]>('/devices');
  kpis = () => this.req<Kpis>('/kpis');
  audit = () => this.req<AuditEntry[]>('/audit');
  transition = (id: string, action: AlertAction, note?: string) =>
    this.req<Alert>(`/alerts/${id}/transition`, { method: 'POST', body: JSON.stringify({ action, note }) });
  assign = (id: string, assignee: string | null) =>
    this.req<Alert>(`/alerts/${id}/assign`, { method: 'POST', body: JSON.stringify({ assignee }) });
  mute = (id: string, muted: boolean) =>
    this.req<Device>(`/devices/${id}/mute`, { method: 'POST', body: JSON.stringify({ muted }) });

  subscribe(onEvent: (e: HubEvent) => void, onState: (s: ConnectionState) => void) {
    onState('connecting');
    // EventSource can't send headers, so the token goes in the query string.
    const es = new EventSource(`/api/stream?token=${encodeURIComponent(this.token ?? '')}`);
    es.onopen = () => onState('live');
    es.onerror = () => onState('reconnecting'); // EventSource retries on its own
    for (const type of ['reading', 'alert', 'device'] as const) {
      es.addEventListener(type, (m) => onEvent(JSON.parse((m as MessageEvent).data)));
    }
    es.addEventListener('kpis', (m) => {
      const data = JSON.parse((m as MessageEvent).data);
      onEvent('type' in data ? data : { type: 'kpis', kpis: data });
    });
    return () => es.close();
  }
}

// --- Runs the same core in the browser, for the standalone demo -------------

export class DemoClient implements HubClient {
  readonly mode = 'demo' as const;
  private hub: TriageHub;
  private sim = new Simulator(7);
  private user: User | undefined;

  constructor() {
    // Replay 5 minutes of history on a fake clock so the dashboard isn't
    // empty on load, then hand the clock back to real time.
    let clock: number | null = Date.now() - 300_000;
    this.hub = new TriageHub({ now: () => clock ?? Date.now() });
    for (let t = 0; t < 300; t++, clock += 1000) this.hub.ingest({ readings: this.sim.tick(clock) });
    clock = null;
    setInterval(() => this.hub.ingest({ readings: this.sim.tick() }), 1000);
    setInterval(() => this.hub.publishKpis(), 2000);
  }

  private run<T>(fn: () => T): Promise<T> {
    try {
      return Promise.resolve(structuredClone(fn()));
    } catch (e) {
      if (e instanceof HubError) return Promise.reject(new ApiError(e.status, e.code, e.message));
      return Promise.reject(e);
    }
  }

  private me(): User {
    if (!this.user) throw new HubError(401, 'unauthorized', 'Not signed in');
    return this.user;
  }

  setToken(token: string | null) {
    this.user = userFromToken(token);
  }

  users = () => Promise.resolve(DEMO_USERS.map((u) => ({ ...u, token: tokenFor(u) })));
  readings = (q: ReadingQuery = {}) => this.run(() => (this.me(), this.hub.listReadings(q)));
  alerts = (q: AlertQuery = {}) => this.run(() => (this.me(), this.hub.listAlerts(q)));
  devices = () => this.run(() => (this.me(), this.hub.listDevices()));
  kpis = () => this.run(() => (this.me(), this.hub.kpis()));
  audit = () => this.run(() => this.hub.getAudit(this.me()));
  transition = (id: string, action: AlertAction, note?: string) =>
    this.run(() => this.hub.transition(id, this.me(), action, note));
  assign = (id: string, assignee: string | null) => this.run(() => this.hub.assign(id, this.me(), assignee));
  mute = (id: string, muted: boolean) => this.run(() => this.hub.setMuted(id, this.me(), muted));

  subscribe(onEvent: (e: HubEvent) => void, onState: (s: ConnectionState) => void) {
    onState('live');
    return this.hub.subscribe((e) => onEvent(structuredClone(e)));
  }
}

declare const __DEMO__: boolean;
export const client: HubClient = typeof __DEMO__ !== 'undefined' && __DEMO__ ? new DemoClient() : new HttpClient();
