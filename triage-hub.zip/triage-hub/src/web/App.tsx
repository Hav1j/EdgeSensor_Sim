import { useEffect, useMemo, useState } from 'react';
import type { User } from '../core/types';
import { can } from '../core/workflow';
import { client, type UserWithToken } from './api';
import { AlertsView } from './components/AlertsView';
import { AuditView, DevicesView } from './components/DevicesView';
import { KpiBar } from './components/KpiBar';
import { ReadingsView } from './components/ReadingsView';
import { cap } from './format';
import { useHub } from './useHub';

type Tab = 'alerts' | 'readings' | 'devices' | 'audit';

const ROLE_BLURB: Record<User['role'], string> = {
  viewer: 'Read-only. Sees everything, changes nothing.',
  operator: 'Triages alerts: acknowledge, escalate, resolve, assign.',
  admin: 'Everything an operator can do, plus reopen alerts, mute devices and read the audit log.',
};

export function App() {
  const [user, setUser] = useState<UserWithToken | null>(null);
  const [tab, setTab] = useState<Tab>('alerts');
  const [paused, setPaused] = useState(false);
  const hub = useHub(client, user !== null, paused);

  const signIn = (u: UserWithToken | null) => {
    client.setToken(u?.token ?? null);
    setUser(u);
    if (u && tab === 'audit' && !can(u.role, 'audit:read')) setTab('alerts');
  };

  const devices = useMemo(() => [...hub.devices.values()].sort((a, b) => a.id.localeCompare(b.id)), [hub.devices]);
  const activeAlerts = useMemo(() => [...hub.alerts.values()].filter((a) => a.status !== 'resolved').length, [hub.alerts]);

  if (!user) return <SignIn onPick={signIn} />;

  const tabs: { id: Tab; label: string; badge?: number }[] = [
    { id: 'alerts', label: 'Alerts', badge: activeAlerts },
    { id: 'readings', label: 'Readings' },
    { id: 'devices', label: 'Devices' },
    ...(can(user.role, 'audit:read') ? [{ id: 'audit' as const, label: 'Audit log' }] : []),
  ];

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="logo" aria-hidden>◆</span> Edge-Sensor Triage Hub
          {client.mode === 'demo' && <span className="tag">demo · runs in your browser</span>}
        </div>
        <div className="row gap">
          <span className={`conn ${hub.connection}`}>
            <span className="dot" /> {hub.connection === 'live' ? 'Live' : cap(hub.connection)}
          </span>
          <span className="who">
            {user.name} <span className={`role role-${user.role}`}>{user.role}</span>
          </span>
          <button className="btn ghost" onClick={() => signIn(null)}>Switch user</button>
        </div>
      </header>

      <KpiBar kpis={hub.kpis} />

      <nav className="tabs" role="tablist">
        {tabs.map((t) => (
          <button key={t.id} role="tab" aria-selected={tab === t.id} className={tab === t.id ? 'on' : ''} onClick={() => setTab(t.id)}>
            {t.label}
            {t.badge ? <span className="badge">{t.badge}</span> : null}
          </button>
        ))}
      </nav>

      <main>
        {tab === 'alerts' && <AlertsView alerts={hub.alerts} user={user} />}
        {tab === 'readings' && (
          <ReadingsView
            readings={hub.readings}
            deviceIds={devices.map((d) => d.id)}
            paused={paused}
            pendingCount={hub.pendingCount}
            onTogglePause={() => setPaused((p) => !p)}
          />
        )}
        {tab === 'devices' && <DevicesView devices={devices} user={user} />}
        {tab === 'audit' && <AuditView />}
      </main>
    </div>
  );
}

function SignIn({ onPick }: { onPick: (u: UserWithToken) => void }) {
  const [users, setUsers] = useState<UserWithToken[]>([]);
  const [error, setError] = useState(false);
  useEffect(() => {
    client.users().then(setUsers).catch(() => setError(true));
  }, []);

  return (
    <div className="signin">
      <div className="signin-card">
        <div className="brand big"><span className="logo" aria-hidden>◆</span> Edge-Sensor Triage Hub</div>
        <p className="muted">
          Simulated edge devices stream telemetry into an ingest API. Anomalies become alerts that operators triage.
          Pick a role to see how permissions change the app.
        </p>
        {error && <div className="error">Can't reach the API. Is the server running on port 4000?</div>}
        <div className="roles">
          {users.map((u) => (
            <button key={u.id} className="role-card" onClick={() => onPick(u)}>
              <div className="row gap">
                <strong>{u.name}</strong>
                <span className={`role role-${u.role}`}>{u.role}</span>
              </div>
              <div className="muted small">{ROLE_BLURB[u.role]}</div>
            </button>
          ))}
        </div>
        <p className="muted small credit">Built by Mike Shirnazar · React, TypeScript, Node, Python</p>
      </div>
    </div>
  );
}
