import { useState } from 'react';
import type { Alert, AlertAction, User } from '../../core/types';
import { availableActions, can, TRANSITIONS } from '../../core/workflow';
import { client, ApiError } from '../api';
import { cap } from '../format';

const LABEL: Record<AlertAction, string> = {
  acknowledge: 'Acknowledge',
  escalate: 'Escalate',
  resolve: 'Resolve',
  reopen: 'Reopen',
};

/**
 * Triage form. The UI uses the same `availableActions` / `TRANSITIONS` rules
 * as the server, so buttons match what the API will accept, but the server
 * still enforces them; the UI is never the security boundary.
 */
export function WorkflowForm({ alert, user }: { alert: Alert; user: User }) {
  const actions = availableActions(user.role, alert.status);
  const [action, setAction] = useState<AlertAction | null>(actions[0] ?? null);
  const [note, setNote] = useState('');
  const [assignee, setAssignee] = useState(alert.assignee ?? '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const current = action && actions.includes(action) ? action : actions[0] ?? null;
  const noteRequired = current ? TRANSITIONS[current].noteRequired : false;
  const canTriage = can(user.role, 'alerts:triage');

  if (actions.length === 0 && !canTriage) {
    return (
      <div className="callout">
        You're signed in as a <strong>{user.role}</strong>. Viewers can follow alerts but not change them.
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!current) return;
    setBusy(true);
    setError(null);
    try {
      await client.transition(alert.id, current, note || undefined);
      setNote('');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Something went wrong');
    } finally {
      setBusy(false);
    }
  };

  const saveAssignee = async () => {
    if ((alert.assignee ?? '') === assignee.trim()) return;
    try {
      await client.assign(alert.id, assignee.trim() || null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not assign');
    }
  };

  return (
    <form className="workflow" onSubmit={submit} aria-label="Triage">
      <h4>Triage</h4>
      {actions.length > 0 ? (
        <>
          <div className="segmented" role="radiogroup" aria-label="Action">
            {actions.map((a) => (
              <button
                type="button"
                role="radio"
                aria-checked={current === a}
                key={a}
                className={current === a ? 'on' : ''}
                onClick={() => setAction(a)}
              >
                {LABEL[a]}
              </button>
            ))}
          </div>
          <label className="field">
            <span>
              Note {noteRequired ? <em className="req">required</em> : <em className="muted">optional</em>}
            </span>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
              placeholder={current === 'resolve' ? 'What was the cause and what fixed it?' : current === 'escalate' ? 'Why does this need escalating, and to whom?' : 'Context for the next person'}
            />
          </label>
        </>
      ) : (
        <p className="muted small">
          No actions available for a {alert.status} alert{alert.status === 'resolved' && !can(user.role, 'alerts:reopen') ? ' (only admins can reopen)' : ''}.
        </p>
      )}

      {canTriage && alert.status !== 'resolved' && (
        <label className="field">
          <span>Assignee</span>
          <input value={assignee} onChange={(e) => setAssignee(e.target.value)} onBlur={saveAssignee} placeholder="Unassigned" />
        </label>
      )}

      {error && <div className="error" role="alert">{error}</div>}

      {current && (
        <button className="btn primary" disabled={busy || (noteRequired && !note.trim())}>
          {busy ? 'Saving…' : `${LABEL[current]} alert`}
        </button>
      )}
      {current && <div className="muted small">Moves the alert to “{cap(TRANSITIONS[current].to)}”.</div>}
    </form>
  );
}
