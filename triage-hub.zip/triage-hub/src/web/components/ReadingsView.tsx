import { useMemo, useState } from 'react';
import { normalizeQ, readingMatches } from '../../core/hub';
import { SENSOR_KINDS, type Reading, type ReadingQuery } from '../../core/types';
import { cap, dateTime, time } from '../format';
import { Empty, SeverityPill } from './ui';

interface Props {
  readings: Reading[];
  deviceIds: string[];
  paused: boolean;
  pendingCount: number;
  onTogglePause: () => void;
}

export function ReadingsView({ readings, deviceIds, paused, pendingCount, onTogglePause }: Props) {
  const [query, setQuery] = useState<ReadingQuery>({ severity: 'anomalous' });
  const [selected, setSelected] = useState<Reading | null>(null);

  const rows = useMemo(() => {
    const q = normalizeQ(query.q);
    return readings.filter((r) => readingMatches(r, query, q)).slice(0, 300);
  }, [readings, query]);

  const set = (patch: Partial<ReadingQuery>) => setQuery((q) => ({ ...q, ...patch }));

  return (
    <div className="split">
      <section className="panel grow">
        <div className="toolbar">
          <input
            type="search"
            placeholder="Search device, flag, payload…"
            value={query.q ?? ''}
            onChange={(e) => set({ q: e.target.value })}
            aria-label="Search readings"
          />
          <select value={query.severity ?? ''} onChange={(e) => set({ severity: (e.target.value || undefined) as ReadingQuery['severity'] })} aria-label="Severity">
            <option value="">All severities</option>
            <option value="anomalous">Anomalous only</option>
            <option value="critical">Critical</option>
            <option value="warning">Warning</option>
            <option value="ok">OK</option>
          </select>
          <select value={query.sensor ?? ''} onChange={(e) => set({ sensor: (e.target.value || undefined) as ReadingQuery['sensor'] })} aria-label="Sensor">
            <option value="">All sensors</option>
            {SENSOR_KINDS.map((s) => (
              <option key={s} value={s}>{cap(s)}</option>
            ))}
          </select>
          <select value={query.deviceId ?? ''} onChange={(e) => set({ deviceId: e.target.value || undefined })} aria-label="Device">
            <option value="">All devices</option>
            {deviceIds.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
          <button className={`btn ghost ${paused ? 'active' : ''}`} onClick={onTogglePause} aria-pressed={paused}>
            {paused ? `▶ Resume${pendingCount ? ` (${pendingCount} new)` : ''}` : '❚❚ Pause'}
          </button>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Received</th>
                <th>Device</th>
                <th>Sensor</th>
                <th className="num">Value</th>
                <th>Severity</th>
                <th>Flags</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr
                  key={r.id}
                  className={`clickable ${selected?.id === r.id ? 'selected' : ''} row-${r.severity}`}
                  onClick={() => setSelected(r)}
                  tabIndex={0}
                  onKeyDown={(e) => e.key === 'Enter' && setSelected(r)}
                >
                  <td className="mono">{time(r.receivedAt)}</td>
                  <td>{r.deviceId}</td>
                  <td>{cap(r.sensor)}</td>
                  <td className="num mono">
                    {r.value.toFixed(2)} <span className="unit">{r.unit}</span>
                  </td>
                  <td><SeverityPill severity={r.severity} /></td>
                  <td className="flags">{r.flags.map((f) => f.code.replace('_', ' ')).join(', ')}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {rows.length === 0 && <Empty>No readings match these filters yet.</Empty>}
        </div>
        <div className="footnote">Showing {rows.length} of the latest {readings.length} readings in the live buffer.</div>
      </section>

      {selected && <PayloadInspector reading={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

function PayloadInspector({ reading, onClose }: { reading: Reading; onClose: () => void }) {
  return (
    <aside className="panel side" aria-label="Payload inspector">
      <header className="side-head">
        <h3>Reading <span className="mono">{reading.id}</span></h3>
        <button className="btn ghost icon" onClick={onClose} aria-label="Close">×</button>
      </header>
      <dl className="facts">
        <dt>Device</dt><dd>{reading.deviceId}</dd>
        <dt>Sensor</dt><dd>{cap(reading.sensor)}</dd>
        <dt>Value</dt><dd className="mono">{reading.value} {reading.unit}</dd>
        <dt>Severity</dt><dd><SeverityPill severity={reading.severity} /></dd>
        <dt>Device time</dt><dd className="mono">{dateTime(reading.ts)}</dd>
        <dt>Received</dt><dd className="mono">{dateTime(reading.receivedAt)}</dd>
      </dl>
      {reading.flags.length > 0 && (
        <>
          <h4>Why it was flagged</h4>
          <ul className="flag-list">
            {reading.flags.map((f) => (
              <li key={f.code}><code>{f.code}</code> {f.message}</li>
            ))}
          </ul>
        </>
      )}
      <h4>Raw payload</h4>
      <pre className="json">{JSON.stringify(reading.payload, null, 2)}</pre>
    </aside>
  );
}
