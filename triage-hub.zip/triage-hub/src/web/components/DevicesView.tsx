import { useEffect, useState } from 'react';
import type { AuditEntry } from '../../core/hub';
import type { Device, User } from '../../core/types';
import { can } from '../../core/workflow';
import { client, ApiError } from '../api';
import { ago, dateTime } from '../format';
import { Empty } from './ui';

const ONLINE_MS = 30_000;

export function DevicesView({ devices, user }: { devices: Device[]; user: User }) {
  const [error, setError] = useState<string | null>(null);
  const canMute = can(user.role, 'devices:mute');
  const now = useNow(1000);

  const toggle = async (d: Device) => {
    setError(null);
    try {
      await client.mute(d.id, !d.muted);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not update device');
    }
  };

  return (
    <section className="panel grow">
      {!canMute && <div className="callout">Muting devices is admin-only. You can see the fleet but not change it.</div>}
      {error && <div className="error" role="alert">{error}</div>}
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Device</th>
              <th>Status</th>
              <th>Last seen</th>
              <th className="num">Readings</th>
              <th>Alerts</th>
            </tr>
          </thead>
          <tbody>
            {devices.map((d) => {
              const online = now - d.lastSeen < ONLINE_MS;
              return (
                <tr key={d.id}>
                  <td className="mono">{d.id}</td>
                  <td>
                    <span className={`dot ${online ? 'on' : 'off'}`} /> {online ? 'Online' : 'Offline'}
                  </td>
                  <td className="muted">{ago(d.lastSeen, now)}</td>
                  <td className="num mono">{d.readingCount.toLocaleString('sv-SE')}</td>
                  <td>
                    <label className={`switch ${canMute ? '' : 'disabled'}`} title={canMute ? '' : 'Admin only'}>
                      <input type="checkbox" checked={!d.muted} disabled={!canMute} onChange={() => toggle(d)} />
                      <span>{d.muted ? 'Muted' : 'Enabled'}</span>
                    </label>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {devices.length === 0 && <Empty>No devices have reported yet. Start the simulator.</Empty>}
      </div>
    </section>
  );
}

export function AuditView() {
  const [entries, setEntries] = useState<AuditEntry[] | null>(null);
  useEffect(() => {
    const load = () => client.audit().then(setEntries).catch(() => setEntries([]));
    load();
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, []);

  return (
    <section className="panel grow">
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>When</th><th>Who</th><th>Action</th><th>Target</th><th>Detail</th></tr>
          </thead>
          <tbody>
            {entries?.map((e, i) => (
              <tr key={i}>
                <td className="mono">{dateTime(e.at)}</td>
                <td>{e.by} <span className="muted small">({e.role})</span></td>
                <td>{e.action}</td>
                <td className="mono">{e.target}</td>
                <td className="muted">{e.detail ?? ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {entries?.length === 0 && <Empty>No actions yet. Every triage and mute action lands here.</Empty>}
      </div>
    </section>
  );
}

function useNow(intervalMs: number) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}
