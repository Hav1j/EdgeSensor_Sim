import { useMemo, useState } from 'react';
import { alertMatches, normalizeQ, sortAlerts } from '../../core/hub';
import type { Alert, AlertQuery, User } from '../../core/types';
import { cap, dateTime, ago } from '../format';
import { WorkflowForm } from './WorkflowForm';
import { Empty, SeverityPill, StatusPill } from './ui';

interface Props {
  alerts: Map<string, Alert>;
  user: User;
}

export function AlertsView({ alerts, user }: Props) {
  const [query, setQuery] = useState<AlertQuery>({ status: 'active' });
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const rows = useMemo(() => {
    const q = normalizeQ(query.q);
    return sortAlerts([...alerts.values()].filter((a) => alertMatches(a, query, q)));
  }, [alerts, query]);

  // Always read the selected alert from the live map so it updates in place.
  const selected = selectedId ? alerts.get(selectedId) : undefined;
  const set = (patch: Partial<AlertQuery>) => setQuery((q) => ({ ...q, ...patch }));

  return (
    <div className="split">
      <section className="panel grow">
        <div className="toolbar">
          <input
            type="search"
            placeholder="Search alerts, devices, assignees…"
            value={query.q ?? ''}
            onChange={(e) => set({ q: e.target.value })}
            aria-label="Search alerts"
          />
          <div className="segmented" role="group" aria-label="Status">
            {(['active', 'open', 'acknowledged', 'escalated', 'resolved'] as const).map((s) => (
              <button key={s} className={query.status === s ? 'on' : ''} onClick={() => set({ status: s })}>
                {cap(s)}
              </button>
            ))}
            <button className={!query.status ? 'on' : ''} onClick={() => set({ status: undefined })}>All</button>
          </div>
          <select value={query.severity ?? ''} onChange={(e) => set({ severity: (e.target.value || undefined) as AlertQuery['severity'] })} aria-label="Severity">
            <option value="">Any severity</option>
            <option value="critical">Critical</option>
            <option value="warning">Warning</option>
          </select>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Severity</th>
                <th>Alert</th>
                <th>Status</th>
                <th className="num">Hits</th>
                <th>Last seen</th>
                <th>Assignee</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((a) => (
                <tr
                  key={a.id}
                  className={`clickable ${selectedId === a.id ? 'selected' : ''}`}
                  onClick={() => setSelectedId(a.id)}
                  tabIndex={0}
                  onKeyDown={(e) => e.key === 'Enter' && setSelectedId(a.id)}
                >
                  <td><SeverityPill severity={a.severity} /></td>
                  <td>
                    <div>{a.title}</div>
                    <div className="muted mono small">{a.id}</div>
                  </td>
                  <td><StatusPill status={a.status} /></td>
                  <td className="num mono">{a.count}</td>
                  <td className="muted">{ago(a.lastSeen)}</td>
                  <td>{a.assignee ?? <span className="muted">–</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {rows.length === 0 && <Empty>Nothing here. Quiet shift.</Empty>}
        </div>
      </section>

      {selected && <AlertDetail alert={selected} user={user} onClose={() => setSelectedId(null)} />}
    </div>
  );
}

function AlertDetail({ alert, user, onClose }: { alert: Alert; user: User; onClose: () => void }) {
  return (
    <aside className="panel side" aria-label="Alert details">
      <header className="side-head">
        <div>
          <h3>{alert.title}</h3>
          <div className="row gap">
            <SeverityPill severity={alert.severity} />
            <StatusPill status={alert.status} />
            <span className="muted mono small">{alert.id}</span>
          </div>
        </div>
        <button className="btn ghost icon" onClick={onClose} aria-label="Close">×</button>
      </header>

      <dl className="facts">
        <dt>Device</dt><dd>{alert.deviceId}</dd>
        <dt>Sensor</dt><dd>{cap(alert.sensor)}</dd>
        <dt>First seen</dt><dd className="mono">{dateTime(alert.firstSeen)}</dd>
        <dt>Last seen</dt><dd className="mono">{dateTime(alert.lastSeen)}</dd>
        <dt>Readings</dt><dd>{alert.count}</dd>
      </dl>

      <WorkflowForm key={alert.id} alert={alert} user={user} />

      <h4>History</h4>
      <ol className="timeline">
        {[...alert.history].reverse().map((h, i) => (
          <li key={i}>
            <div>
              <strong>{h.by}</strong> {h.action === 'created' ? 'opened the alert' : h.action === 'updated' ? 'updated' : `${h.action}d`}
              {h.from && h.to && h.from !== h.to && <span className="muted"> ({h.from} → {h.to})</span>}
            </div>
            {h.note && <div className="note">{h.note}</div>}
            <div className="muted small mono">{dateTime(h.at)}</div>
          </li>
        ))}
      </ol>
    </aside>
  );
}
