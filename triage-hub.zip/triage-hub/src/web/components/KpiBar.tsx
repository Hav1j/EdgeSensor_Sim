import type { Kpis } from '../../core/types';
import { duration, pct } from '../format';

export function KpiBar({ kpis }: { kpis: Kpis | null }) {
  if (!kpis) return <section className="kpis skeleton" aria-busy="true" />;
  const open = kpis.openBySeverity.critical + kpis.openBySeverity.warning;
  return (
    <section className="kpis" aria-label="Key metrics">
      <Tile label="Readings / min" value={kpis.readingsPerMin.toLocaleString('sv-SE')}>
        <Sparkline values={kpis.throughput} />
      </Tile>
      <Tile label="Anomaly rate (1 min)" value={pct(kpis.anomalyRate)} tone={kpis.anomalyRate > 0.05 ? 'warn' : undefined} />
      <Tile
        label="Active alerts"
        value={String(open)}
        sub={`${kpis.openBySeverity.critical} critical · ${kpis.openBySeverity.warning} warning`}
        tone={kpis.openBySeverity.critical ? 'crit' : open ? 'warn' : undefined}
      />
      <Tile label="Unacknowledged" value={String(kpis.unacknowledged)} sub={`${kpis.escalated} escalated`} tone={kpis.unacknowledged ? 'warn' : undefined} />
      <Tile label="Mean time to ack" value={duration(kpis.mttaMs)} />
      <Tile
        label="Devices online"
        value={`${kpis.devicesOnline}/${kpis.devicesTotal}`}
        tone={kpis.devicesOnline < kpis.devicesTotal ? 'warn' : undefined}
      />
      <Tile label="Rejected payloads" value={String(kpis.rejectedPayloads)} sub="failed validation" />
    </section>
  );
}

function Tile(props: { label: string; value: string; sub?: string; tone?: 'warn' | 'crit'; children?: React.ReactNode }) {
  return (
    <div className={`tile ${props.tone ?? ''}`}>
      <div className="tile-label">{props.label}</div>
      <div className="tile-value">{props.value}</div>
      {props.sub && <div className="tile-sub">{props.sub}</div>}
      {props.children}
    </div>
  );
}

export function Sparkline({ values }: { values: number[] }) {
  const w = 120;
  const h = 28;
  const max = Math.max(1, ...values);
  const step = w / Math.max(1, values.length - 1);
  const points = values.map((v, i) => `${(i * step).toFixed(1)},${(h - (v / max) * (h - 2) - 1).toFixed(1)}`).join(' ');
  return (
    <svg className="spark" viewBox={`0 0 ${w} ${h}`} width={w} height={h} role="img" aria-label="Throughput, last 5 minutes">
      <polyline points={points} fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
}
