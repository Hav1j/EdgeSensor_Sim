import type { AlertStatus, Severity } from '../../core/types';
import { cap } from '../format';

export function SeverityPill({ severity }: { severity: Severity }) {
  return <span className={`pill sev-${severity}`}>{severity === 'ok' ? 'OK' : cap(severity)}</span>;
}

export function StatusPill({ status }: { status: AlertStatus }) {
  return <span className={`pill status-${status}`}>{cap(status)}</span>;
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="empty">{children}</div>;
}
