import { useEffect, useRef, useState } from 'react';
import type { Alert, Device, HubEvent, Kpis, Reading } from '../core/types';
import type { ConnectionState, HubClient } from './api';

const LIVE_BUFFER = 1000;

export interface HubState {
  readings: Reading[];
  alerts: Map<string, Alert>;
  devices: Map<string, Device>;
  kpis: Kpis | null;
  connection: ConnectionState;
  /** Readings that arrived while the table was paused. */
  pendingCount: number;
}

/**
 * Loads a snapshot, then keeps it current from the live event stream.
 * Readings are batched into one render per animation frame so a busy
 * stream doesn't re-render the table hundreds of times a second.
 */
export function useHub(client: HubClient, signedIn: boolean, paused: boolean): HubState {
  const [readings, setReadings] = useState<Reading[]>([]);
  const [alerts, setAlerts] = useState(new Map<string, Alert>());
  const [devices, setDevices] = useState(new Map<string, Device>());
  const [kpis, setKpis] = useState<Kpis | null>(null);
  const [connection, setConnection] = useState<ConnectionState>('connecting');
  const [pendingCount, setPendingCount] = useState(0);

  const pending = useRef<Reading[]>([]);
  const pausedRef = useRef(paused);
  pausedRef.current = paused;

  useEffect(() => {
    if (!signedIn) return;
    let cancelled = false;
    let frame = 0;

    const flush = () => {
      frame = 0;
      if (pausedRef.current) {
        setPendingCount(pending.current.length);
        return;
      }
      const batch = pending.current;
      pending.current = [];
      setPendingCount(0);
      if (batch.length) setReadings((prev) => [...batch.reverse(), ...prev].slice(0, LIVE_BUFFER));
    };

    const onEvent = (e: HubEvent) => {
      if (cancelled) return;
      switch (e.type) {
        case 'reading':
          pending.current.push(e.reading);
          if (pending.current.length > LIVE_BUFFER) pending.current.shift();
          if (!frame) frame = requestAnimationFrame(flush);
          break;
        case 'alert':
          setAlerts((prev) => new Map(prev).set(e.alert.id, e.alert));
          break;
        case 'device':
          setDevices((prev) => new Map(prev).set(e.device.id, e.device));
          break;
        case 'kpis':
          setKpis(e.kpis);
          break;
      }
    };

    // Subscribe first so nothing is missed between the snapshot and the stream.
    const unsubscribe = client.subscribe(onEvent, setConnection);
    Promise.all([client.readings({ limit: LIVE_BUFFER }), client.alerts(), client.devices(), client.kpis()])
      .then(([r, a, d, k]) => {
        if (cancelled) return;
        setReadings((live) => dedupe([...live, ...r]).slice(0, LIVE_BUFFER));
        setAlerts((live) => new Map([...a.map((x) => [x.id, x] as const), ...live]));
        setDevices((live) => new Map([...d.map((x) => [x.id, x] as const), ...live]));
        setKpis(k);
      })
      .catch((err) => console.error('snapshot failed', err));

    return () => {
      cancelled = true;
      unsubscribe();
      if (frame) cancelAnimationFrame(frame);
    };
  }, [client, signedIn]);

  // Resuming the table flushes whatever queued up while paused.
  useEffect(() => {
    if (!paused && pending.current.length) {
      const batch = pending.current;
      pending.current = [];
      setPendingCount(0);
      setReadings((prev) => [...batch.reverse(), ...prev].slice(0, LIVE_BUFFER));
    }
  }, [paused]);

  return { readings, alerts, devices, kpis, connection, pendingCount };
}

function dedupe(rs: Reading[]): Reading[] {
  const seen = new Set<string>();
  return rs.filter((r) => (seen.has(r.id) ? false : (seen.add(r.id), true)));
}
