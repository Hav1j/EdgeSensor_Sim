export const time = (ms: number) =>
  new Date(ms).toLocaleTimeString('sv-SE', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

export const dateTime = (ms: number) =>
  new Date(ms).toLocaleString('sv-SE', { dateStyle: 'short', timeStyle: 'medium' });

export function ago(ms: number, now = Date.now()): string {
  const s = Math.max(0, Math.round((now - ms) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  return `${Math.round(m / 60)} h ago`;
}

export function duration(ms: number | null): string {
  if (ms === null) return '–';
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s}s`;
  return `${Math.floor(s / 60)}m ${s % 60}s`;
}

export const pct = (x: number) => `${(x * 100).toFixed(1)}%`;

export const cap = (s: string) => s[0]!.toUpperCase() + s.slice(1);
