import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// `--mode demo` builds a single self-contained HTML file that runs the whole
// backend in the browser (same core domain code), so the app can be shown
// without a server. Normal builds talk to the Node API.
export default defineConfig(({ mode }) => ({
  root: 'src/web',
  plugins: mode === 'demo' ? [react(), viteSingleFile()] : [react()],
  define: { __DEMO__: JSON.stringify(mode === 'demo') },
  build: {
    outDir: mode === 'demo' ? '../../dist-demo' : '../../dist',
    emptyOutDir: true,
  },
  server: {
    port: 5173,
    proxy: { '/api': { target: 'http://localhost:4000', changeOrigin: true } },
  },
  test: {
    root: '.',
    include: ['tests/**/*.test.{ts,tsx}'],
    environment: 'node',
  },
}));
