# Edge-Sensor Triage Hub

A small operations tool: simulated edge devices push telemetry to an ingest webhook, the backend flags anomalous readings, and operators triage the resulting alerts in a live dashboard.

**Stack:** React + TypeScript (Vite) · Node + Express + TypeScript · Zod · Server-Sent Events · Vitest + Testing Library + Supertest · Python simulator

![Alerts view](docs/alerts.png)

## Run it

```bash
npm install
npm run dev          # API on :4000, web app on :5173
npm run simulate     # in another terminal: Python fleet simulator (stdlib only)
```

Open http://localhost:5173 and pick a role. No Python? Run `npx tsx server/index.ts --sim` to use the built-in TypeScript simulator instead.

```bash
npm test             # 41 tests: rules, workflow, hub, HTTP API, React form
npm run typecheck
npm run build:demo   # single self-contained HTML file that runs everything in the browser
```

## What it does

| Area | What's there |
|---|---|
| **Ingest** | `POST /api/ingest` takes one reading or a batch of up to 500. API-key auth. Each item is validated on its own (schema, unit, physical range), so one bad payload doesn't sink the batch. Returns `202` with itemised rejects, or `422` if nothing was valid. |
| **Anomaly rules** | Per-sensor warning/critical thresholds (high and low), a rolling z-score for sudden spikes, and device clock-skew detection. Every flag carries a one-line explanation an operator can read. |
| **Alerts** | Anomalies fold into one active alert per device + sensor instead of flooding the list. Severity can rise but never silently falls. A muted device still stores readings but raises no alerts. |
| **Workflow** | `open → acknowledged → resolved`, `escalated` from either, `reopen` from resolved. Notes are required for escalate, resolve and reopen. Every change lands in the alert's history and a global audit log. |
| **RBAC** | **Viewer** reads. **Operator** triages and assigns. **Admin** also reopens, mutes devices and reads the audit log. Enforced on the server; the UI uses the same rule table so buttons match what the API accepts. |
| **Live UI** | KPIs (throughput sparkline, anomaly rate, active and unacknowledged alerts, mean time to acknowledge, devices online, rejected payloads), a searchable and filterable readings table with a pause button and payload inspector, and the alert queue with a triage form and history. |

## Architecture

```
simulator/simulate.py ──POST /api/ingest──▶ server/app.ts (Express: auth, validation, HTTP)
                                                  │
                                                  ▼
                                    src/core/hub.ts  (TriageHub: framework-free domain)
                                      ├─ rules.ts       thresholds, z-score, clock skew
                                      ├─ workflow.ts    state machine + permissions
                                      └─ validation.ts  Zod schemas
                                                  │ events
                                                  ▼
                                   GET /api/stream (SSE) ──▶ src/web (React)
```

The decision that shaped the rest: **all domain logic lives in `src/core` with no framework imports.** That gave three things:

1. **Tests are fast and direct.** Most tests hit `TriageHub` with an injected clock and no HTTP. The API tests then only check the HTTP layer: status codes, auth, parsing.
2. **The client and server can't disagree.** The React app imports the same `availableActions`, `readingMatches` and `alertMatches` the server uses, so a button shows only when the API will accept the action, and live filtering behaves exactly like the query endpoint.
3. **The demo build runs the real backend in the browser.** `build:demo` swaps `HttpClient` for `DemoClient`, which runs the same `TriageHub` plus a TypeScript port of the simulator. No mocks; it's the same code.

Other choices:
- **SSE over WebSockets.** Data flows one way, server to client. SSE reconnects on its own and works through ordinary HTTP. Writes go through REST.
- **Batched rendering.** Readings arrive many times a second. The client batches them into one render per animation frame and keeps a bounded buffer.
- **Plain rules, not ML.** Triage tools live or die on whether operators trust the flags. A threshold or a z-score can be explained in a sentence; a model score can't.
- **In-memory store.** Fine for a demo. `TriageHub` is the only stateful class, so swapping in Postgres or Redis stays a local change.

## API

| Method | Path | Who | Notes |
|---|---|---|---|
| POST | `/api/ingest` | device (`X-Api-Key`) | single reading or `{ readings: [...] }` |
| GET | `/api/readings` | any user | `q`, `severity` (`ok`/`warning`/`critical`/`anomalous`), `sensor`, `deviceId`, `limit` |
| GET | `/api/alerts` | any user | `status` (incl. `active`), `severity`, `q` |
| POST | `/api/alerts/:id/transition` | operator+ | `{ action, note? }` → 403 / 409 / 422 on refusal |
| POST | `/api/alerts/:id/assign` | operator+ | `{ assignee }` |
| GET | `/api/devices` | any user | |
| POST | `/api/devices/:id/mute` | admin | `{ muted }` |
| GET | `/api/audit` | admin | |
| GET | `/api/kpis` | any user | |
| GET | `/api/stream` | any user | SSE: `reading`, `alert`, `device`, `kpis` |

Auth uses demo bearer tokens (`demo.sara`, `demo.erik`, `demo.amira`). In production that would be SSO/JWT; the server only depends on `userFromToken`, so the swap stays in one file.

## Example payload

```json
{
  "deviceId": "press-line-01",
  "sensor": "temperature",
  "value": 71.4,
  "unit": "°C",
  "ts": "2026-11-19T13:05:26.383Z",
  "meta": { "fw": "2.4.1" }
}
```

## How it was built

I built this with Claude Code as a pair programmer, the same way I work day to day. I made the design decisions above, reviewed every module, and the test suite is what confirms the behaviour, not the model's say-so.

— Mike Shirnazar · mike@shirnazar.com
