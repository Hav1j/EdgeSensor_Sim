import { describe, expect, it } from 'vitest';
import { availableActions, can, checkTransition } from '../src/core/workflow';

describe('RBAC', () => {
  it('viewers can only read', () => {
    expect(can('viewer', 'alerts:read')).toBe(true);
    expect(can('viewer', 'alerts:triage')).toBe(false);
    expect(availableActions('viewer', 'open')).toEqual([]);
  });

  it('operators triage but cannot reopen or mute', () => {
    expect(availableActions('operator', 'open')).toEqual(['acknowledge', 'escalate']);
    expect(availableActions('operator', 'resolved')).toEqual([]);
    expect(can('operator', 'devices:mute')).toBe(false);
  });

  it('admins can reopen resolved alerts', () => {
    expect(availableActions('admin', 'resolved')).toEqual(['reopen']);
  });
});

describe('alert state machine', () => {
  it('allows the happy path', () => {
    expect(checkTransition('operator', 'open', 'acknowledge')).toEqual({ ok: true, to: 'acknowledged' });
    expect(checkTransition('operator', 'acknowledged', 'resolve', 'Replaced bearing')).toEqual({ ok: true, to: 'resolved' });
  });

  it('rejects invalid transitions', () => {
    const r = checkTransition('admin', 'open', 'resolve', 'note');
    expect(r).toMatchObject({ ok: false, code: 'invalid_transition' });
  });

  it('requires a note to escalate, resolve or reopen', () => {
    expect(checkTransition('operator', 'open', 'escalate', '   ')).toMatchObject({ ok: false, code: 'note_required' });
    expect(checkTransition('admin', 'resolved', 'reopen')).toMatchObject({ ok: false, code: 'note_required' });
  });

  it('checks permission before anything else', () => {
    expect(checkTransition('viewer', 'open', 'acknowledge')).toMatchObject({ ok: false, code: 'forbidden' });
  });
});
