import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../server/app';
import { TriageHub } from '../src/core/hub';

const KEY = 'test-key';
const auth = (who: 'sara' | 'erik' | 'amira') => ({ authorization: `Bearer demo.${who}` });
let app: ReturnType<typeof createApp>;

beforeEach(() => {
  app = createApp(new TriageHub(), { ingestApiKey: KEY });
});

const ingest = (body: unknown) => request(app).post('/api/ingest').set('x-api-key', KEY).send(body as object);

describe('POST /api/ingest', () => {
  it('requires the API key', async () => {
    const res = await request(app).post('/api/ingest').send({ deviceId: 'a', sensor: 'pressure', value: 5 });
    expect(res.status).toBe(401);
  });

  it('returns 202 with per-item results', async () => {
    const res = await ingest({ readings: [{ deviceId: 'a', sensor: 'pressure', value: 5 }, { deviceId: 'a' }] });
    expect(res.status).toBe(202);
    expect(res.body.accepted).toBe(1);
    expect(res.body.rejected).toHaveLength(1);
  });

  it('returns 422 when nothing in the batch is valid', async () => {
    const res = await ingest({ deviceId: 'a', sensor: 'pressure', value: 'x' });
    expect(res.status).toBe(422);
  });

  it('returns 400 for invalid JSON', async () => {
    const res = await request(app).post('/api/ingest').set('x-api-key', KEY).set('content-type', 'application/json').send('{oops');
    expect(res.status).toBe(400);
  });
});

describe('alert workflow over HTTP', () => {
  it('runs acknowledge → resolve with RBAC enforced server-side', async () => {
    await ingest({ deviceId: 'a', sensor: 'pressure', value: 11 });
    const list = await request(app).get('/api/alerts?status=active').set(auth('sara'));
    expect(list.status).toBe(200);
    const id = list.body[0].id;

    const denied = await request(app).post(`/api/alerts/${id}/transition`).set(auth('sara')).send({ action: 'acknowledge' });
    expect(denied.status).toBe(403);

    const ack = await request(app).post(`/api/alerts/${id}/transition`).set(auth('erik')).send({ action: 'acknowledge' });
    expect(ack.body.status).toBe('acknowledged');

    const noNote = await request(app).post(`/api/alerts/${id}/transition`).set(auth('erik')).send({ action: 'resolve' });
    expect(noNote.status).toBe(422);

    const done = await request(app).post(`/api/alerts/${id}/transition`).set(auth('erik')).send({ action: 'resolve', note: 'Valve reseated' });
    expect(done.body.status).toBe('resolved');
  });

  it('validates query params and bodies', async () => {
    expect((await request(app).get('/api/readings?severity=bad').set(auth('sara'))).status).toBe(400);
    expect((await request(app).post('/api/alerts/x/transition').set(auth('erik')).send({ action: 'explode' })).status).toBe(400);
  });

  it('requires a valid token for reads', async () => {
    expect((await request(app).get('/api/readings')).status).toBe(401);
    expect((await request(app).get('/api/readings').set({ authorization: 'Bearer nope' })).status).toBe(401);
  });

  it('filters readings by query', async () => {
    await ingest({ readings: [{ deviceId: 'a', sensor: 'pressure', value: 5 }, { deviceId: 'b', sensor: 'pressure', value: 11 }] });
    const res = await request(app).get('/api/readings?severity=anomalous').set(auth('sara'));
    expect(res.body.map((r: { deviceId: string }) => r.deviceId)).toEqual(['b']);
  });

  it('keeps the audit log admin-only', async () => {
    expect((await request(app).get('/api/audit').set(auth('erik'))).status).toBe(403);
    expect((await request(app).get('/api/audit').set(auth('amira'))).status).toBe(200);
  });
});
