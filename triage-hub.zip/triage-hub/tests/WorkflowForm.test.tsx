// @vitest-environment jsdom
import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import type { Alert, User } from '../src/core/types';
import { client } from '../src/web/api';
import { WorkflowForm } from '../src/web/components/WorkflowForm';

const alert: Alert = {
  id: 'a_1', deviceId: 'cnc-07', sensor: 'temperature', severity: 'warning', status: 'open',
  title: 'Temperature high on cnc-07', firstSeen: 0, lastSeen: 0, count: 1, readingIds: [], history: [],
};
const as = (role: User['role']): User => ({ id: role, name: role, role });

afterEach(cleanup);

describe('WorkflowForm', () => {
  it('is read-only for viewers', () => {
    render(<WorkflowForm alert={alert} user={as('viewer')} />);
    expect(screen.getByText(/can follow alerts but not change them/)).toBeTruthy();
    expect(screen.queryByRole('button', { name: /alert$/ })).toBeNull();
  });

  it('only offers transitions valid for the current status', () => {
    render(<WorkflowForm alert={alert} user={as('operator')} />);
    const options = screen.getAllByRole('radio').map((b) => b.textContent);
    expect(options).toEqual(['Acknowledge', 'Escalate']);
  });

  it('blocks submit until a required note is written, then calls the API', async () => {
    const spy = vi.spyOn(client, 'transition').mockResolvedValue({ ...alert, status: 'escalated' });
    const user = userEvent.setup();
    render(<WorkflowForm alert={alert} user={as('operator')} />);

    await user.click(screen.getByRole('radio', { name: 'Escalate' }));
    const submit = screen.getByRole('button', { name: 'Escalate alert' }) as HTMLButtonElement;
    expect(submit.disabled).toBe(true);

    await user.type(screen.getByRole('textbox', { name: /note/i }), 'Bearing noise, needs maintenance');
    expect(submit.disabled).toBe(false);
    await user.click(submit);
    expect(spy).toHaveBeenCalledWith('a_1', 'escalate', 'Bearing noise, needs maintenance');
  });
});
