import { beforeEach, describe, expect, it } from 'vitest';
import { HubError, TriageHub } from '../src/core/hub';
import type { HubEvent, User } from '../src/core/types';
import { DEMO_USERS } from '../src/core/users';

const [viewer, operator, admin] = DEMO_USERS as [User, User, User];

let clock: number;
let hub: TriageHub;
const reading = (over: Record<string, unknown> = {}) => ({ deviceId: 'cnc-07', sensor: 'temperature', value: 48, ...over });
const advance = (ms: number) => (clock += ms);

beforeEach(() => {
  clock = 1_700_000_000_000;
  hub = new TriageHub({ now: () => clock });
});

describe('ingest', () => {
  it('accepts single readings and batches', () => {
    expect(hub.ingest(reading())).toEqual({ accepted: 1, rejected: [] });
    expect(hub.ingest({ readings: [reading(), reading({ sensor: 'vibration', value: 3 })] }).accepted).toBe(2);
    expect(hub.listReadings()).toHaveLength(3);
  });

  it('rejects bad items individually and keeps the good ones', () => {
    const r = hub.ingest({ readings: [reading(), { deviceId: 'x', sensor: 'radiation', value: 1 }, reading({ value: 'hot' })] });
    expect(r.accepted).toBe(1);
    expect(r.rejected.map((x) => x.index)).toEqual([1, 2]);
    expect(r.rejected[0]!.errors[0]).toMatch(/sensor/);
    expect(hub.kpis().rejectedPayloads).toBe(2);
  });

  it('rejects a unit that does not match the sensor', () => {
    const r = hub.ingest(reading({ unit: '°F' }));
    expect(r.rejected[0]!.errors[0]).toMatch(/unit for temperature must be "°C"/);
  });

  it('rejects physically impossible values', () => {
    const r = hub.ingest(reading({ sensor: 'vibration', value: -1 }));
    expect(r.rejected[0]!.errors[0]).toMatch(/outside the physical range/);
  });

  it('throws on a body that is not a reading or batch', () => {
    expect(() => hub.ingest('hello')).toThrow(HubError);
    expect(() => hub.ingest({ readings: [] })).toThrow(/empty/);
  });

  it('accepts ISO timestamps and keeps the raw payload', () => {
    hub.ingest(reading({ ts: new Date(clock).toISOString(), meta: { fw: '1.0' } }));
    const [r] = hub.listReadings();
    expect(r!.ts).toBe(clock);
    expect(r!.payload).toMatchObject({ meta: { fw: '1.0' } });
  });
});

describe('alerts', () => {
  it('opens one alert per device + sensor and folds repeats into it', () => {
    hub.ingest(reading({ value: 75 }));
    hub.ingest(reading({ value: 76 }));
    hub.ingest(reading({ value: 90 })); // escalates severity
    const alerts = hub.listAlerts();
    expect(alerts).toHaveLength(1);
    expect(alerts[0]).toMatchObject({ count: 3, severity: 'critical', status: 'open' });
  });

  it('opens a new alert after the previous one is resolved', () => {
    hub.ingest(reading({ value: 75 }));
    const [a] = hub.listAlerts();
    hub.transition(a!.id, operator, 'acknowledge');
    hub.transition(a!.id, operator, 'resolve', 'Fan cleaned');
    hub.ingest(reading({ value: 75 }));
    expect(hub.listAlerts({ status: 'active' })).toHaveLength(1);
    expect(hub.listAlerts()).toHaveLength(2);
  });

  it('does not alert for muted devices but still stores readings', () => {
    hub.ingest(reading());
    hub.setMuted('cnc-07', admin, true);
    hub.ingest(reading({ value: 95 }));
    expect(hub.listAlerts()).toHaveLength(0);
    expect(hub.listReadings({ severity: 'critical' })).toHaveLength(1);
  });

  it('enforces RBAC on every write', () => {
    hub.ingest(reading({ value: 75 }));
    const [a] = hub.listAlerts();
    expect(() => hub.transition(a!.id, viewer, 'acknowledge')).toThrow(expect.objectContaining({ status: 403 }));
    expect(() => hub.assign(a!.id, viewer, 'me')).toThrow(expect.objectContaining({ status: 403 }));
    expect(() => hub.setMuted('cnc-07', operator, true)).toThrow(expect.objectContaining({ status: 403 }));
    expect(() => hub.getAudit(operator)).toThrow(expect.objectContaining({ status: 403 }));
  });

  it('maps workflow errors to HTTP-ish statuses', () => {
    hub.ingest(reading({ value: 75 }));
    const [a] = hub.listAlerts();
    expect(() => hub.transition(a!.id, operator, 'resolve', 'x')).toThrow(expect.objectContaining({ status: 409 }));
    expect(() => hub.transition(a!.id, operator, 'escalate')).toThrow(expect.objectContaining({ status: 422 }));
    expect(() => hub.transition('a_nope', operator, 'acknowledge')).toThrow(expect.objectContaining({ status: 404 }));
  });

  it('records history and an audit trail', () => {
    hub.ingest(reading({ value: 75 }));
    const [a] = hub.listAlerts();
    hub.transition(a!.id, operator, 'escalate', 'Smells like smoke');
    const alert = hub.getAlert(a!.id);
    expect(alert.history.map((h) => h.action)).toEqual(['created', 'escalate']);
    expect(hub.getAudit(admin)[0]).toMatchObject({ by: 'Erik', action: 'escalate', detail: 'Smells like smoke' });
  });

  it('returns copies so callers cannot mutate hub state', () => {
    hub.ingest(reading({ value: 75 }));
    const [a] = hub.listAlerts();
    a!.status = 'resolved';
    expect(hub.listAlerts()[0]!.status).toBe('open');
  });
});

describe('kpis', () => {
  it('computes rates, MTTA and online devices', () => {
    hub.ingest({ readings: [reading(), reading({ deviceId: 'press-01', value: 90 })] });
    const [a] = hub.listAlerts();
    advance(30_000);
    hub.transition(a!.id, operator, 'acknowledge');
    advance(5_000);
    hub.ingest(reading());
    const k = hub.kpis();
    expect(k.readingsPerMin).toBe(3);
    expect(k.anomalyRate).toBeCloseTo(1 / 3);
    expect(k.mttaMs).toBe(30_000);
    expect(k.devicesOnline).toBe(1); // press-01 last seen 35 s ago
    expect(k.devicesTotal).toBe(2);
    expect(k.throughput.at(-1)).toBe(1);
  });
});

describe('events', () => {
  it('emits reading, device and alert events', () => {
    const events: HubEvent['type'][] = [];
    hub.subscribe((e) => events.push(e.type));
    hub.ingest(reading({ value: 90 }));
    expect(events).toEqual(['reading', 'device', 'alert']);
  });
});
