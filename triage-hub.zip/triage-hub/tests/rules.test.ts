import { describe, expect, it } from 'vitest';
import { evaluate, MAX_CLOCK_SKEW_MS } from '../src/core/rules';

const NOW = 1_700_000_000_000;
const steady = (v: number, n = 20) => Array.from({ length: n }, (_, i) => v + (i % 2 ? 0.2 : -0.2));

describe('evaluate', () => {
  it('passes a normal reading', () => {
    expect(evaluate('temperature', 48, NOW, NOW, steady(48))).toEqual({ severity: 'ok', flags: [] });
  });

  it('flags warning and critical thresholds, high and low', () => {
    expect(evaluate('temperature', 72, NOW, NOW, []).severity).toBe('warning');
    expect(evaluate('temperature', 90, NOW, NOW, []).flags[0]?.code).toBe('above_critical');
    expect(evaluate('pressure', 0.8, NOW, NOW, []).flags[0]?.code).toBe('below_warning');
    expect(evaluate('pressure', 0.3, NOW, NOW, []).severity).toBe('critical');
  });

  it('treats the threshold value itself as crossed', () => {
    expect(evaluate('vibration', 7.1, NOW, NOW, []).severity).toBe('warning');
  });

  it('detects a spike against recent history even inside thresholds', () => {
    const r = evaluate('temperature', 60, NOW, NOW, steady(48));
    expect(r.severity).toBe('warning');
    expect(r.flags.map((f) => f.code)).toEqual(['spike']);
  });

  it('does not spike-check without enough history', () => {
    expect(evaluate('temperature', 60, NOW, NOW, steady(48, 5)).flags).toEqual([]);
  });

  it('does not flag tiny wobbles on a perfectly flat signal', () => {
    expect(evaluate('pressure', 5.52, NOW, NOW, Array(20).fill(5.5)).flags).toEqual([]);
  });

  it('flags device clock skew', () => {
    const r = evaluate('humidity', 45, NOW - MAX_CLOCK_SKEW_MS - 1000, NOW, []);
    expect(r.flags[0]?.code).toBe('clock_skew');
    expect(r.flags[0]?.message).toMatch(/behind/);
  });
});
