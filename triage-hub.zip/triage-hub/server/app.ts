import express, { type NextFunction, type Request, type Response } from 'express';
import { HubError, type TriageHub } from '../src/core/hub';
import type { User } from '../src/core/types';
import { DEMO_USERS, tokenFor, userFromToken } from '../src/core/users';
import {
  alertQuerySchema,
  assignSchema,
  formatIssues,
  readingQuerySchema,
  transitionSchema,
} from '../src/core/validation';
import type { z } from 'zod';

export interface AppOptions {
  /** Shared secret devices/gateways send in `X-Api-Key` when posting telemetry. */
  ingestApiKey: string;
}

type Authed = Request & { user: User };

export function createApp(hub: TriageHub, opts: AppOptions) {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // --- auth ---------------------------------------------------------------

  app.get('/api/users', (_req, res) => {
    res.json(DEMO_USERS.map((u) => ({ ...u, token: tokenFor(u) })));
  });

  const requireUser = (req: Request, _res: Response, next: NextFunction) => {
    const header = req.header('authorization');
    const token = header?.startsWith('Bearer ') ? header.slice(7) : (req.query.token as string | undefined);
    const user = userFromToken(token);
    if (!user) return next(new HubError(401, 'unauthorized', 'Missing or invalid token'));
    (req as Authed).user = user;
    next();
  };

  const parse = <T extends z.ZodType>(schema: T, data: unknown): z.infer<T> => {
    const r = schema.safeParse(data);
    if (!r.success) throw new HubError(400, 'bad_request', formatIssues(r.error).join('; '));
    return r.data;
  };

  // --- ingest (webhook) -----------------------------------------------------

  app.post('/api/ingest', (req, res) => {
    if (req.header('x-api-key') !== opts.ingestApiKey) {
      throw new HubError(401, 'unauthorized', 'Invalid X-Api-Key');
    }
    const result = hub.ingest(req.body);
    // 202: accepted for processing. Partial batches still succeed; rejects are itemised.
    res.status(result.accepted === 0 && result.rejected.length > 0 ? 422 : 202).json(result);
  });

  // --- reads ----------------------------------------------------------------

  app.get('/api/readings', requireUser, (req, res) => {
    res.json(hub.listReadings(parse(readingQuerySchema, req.query)));
  });
  app.get('/api/readings/:id', requireUser, (req, res) => {
    res.json(hub.getReading(String(req.params.id)));
  });
  app.get('/api/alerts', requireUser, (req, res) => {
    res.json(hub.listAlerts(parse(alertQuerySchema, req.query)));
  });
  app.get('/api/alerts/:id', requireUser, (req, res) => {
    res.json(hub.getAlert(String(req.params.id)));
  });
  app.get('/api/devices', requireUser, (_req, res) => {
    res.json(hub.listDevices());
  });
  app.get('/api/kpis', requireUser, (_req, res) => {
    res.json(hub.kpis());
  });
  app.get('/api/audit', requireUser, (req, res) => {
    res.json(hub.getAudit((req as Authed).user));
  });

  // --- writes ---------------------------------------------------------------

  app.post('/api/alerts/:id/transition', requireUser, (req, res) => {
    const { action, note } = parse(transitionSchema, req.body);
    res.json(hub.transition(String(req.params.id), (req as Authed).user, action, note));
  });
  app.post('/api/alerts/:id/assign', requireUser, (req, res) => {
    const { assignee } = parse(assignSchema, req.body);
    res.json(hub.assign(String(req.params.id), (req as Authed).user, assignee));
  });
  app.post('/api/devices/:id/mute', requireUser, (req, res) => {
    const muted = Boolean((req.body as { muted?: unknown })?.muted);
    res.json(hub.setMuted(String(req.params.id), (req as Authed).user, muted));
  });

  // --- live stream (Server-Sent Events) -------------------------------------

  app.get('/api/stream', requireUser, (req, res) => {
    res.writeHead(200, {
      'content-type': 'text/event-stream',
      'cache-control': 'no-cache',
      connection: 'keep-alive',
    });
    res.write(`event: kpis\ndata: ${JSON.stringify(hub.kpis())}\n\n`);
    const unsubscribe = hub.subscribe((e) => {
      res.write(`event: ${e.type}\ndata: ${JSON.stringify(e)}\n\n`);
    });
    const ping = setInterval(() => res.write(': ping\n\n'), 15_000);
    req.on('close', () => {
      clearInterval(ping);
      unsubscribe();
    });
  });

  // --- errors -----------------------------------------------------------------

  app.use('/api', (_req, _res, next) => next(new HubError(404, 'not_found', 'No such endpoint')));

  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof HubError) {
      res.status(err.status).json({ error: err.code, message: err.message });
      return;
    }
    if (err instanceof SyntaxError) {
      res.status(400).json({ error: 'bad_request', message: 'Body is not valid JSON' });
      return;
    }
    console.error(err);
    res.status(500).json({ error: 'internal', message: 'Something went wrong' });
  });

  return app;
}
