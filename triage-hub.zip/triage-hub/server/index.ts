import { createApp } from './app';
import { TriageHub } from '../src/core/hub';
import { Simulator } from '../src/core/simulator';
import express from 'express';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const PORT = Number(process.env.PORT ?? 4000);
const INGEST_API_KEY = process.env.INGEST_API_KEY ?? 'dev-ingest-key';

const hub = new TriageHub();
const app = createApp(hub, { ingestApiKey: INGEST_API_KEY });

// Serve the built frontend if it exists (npm run build && npm start).
const dist = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../dist');
if (existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/^(?!\/api).*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

// Push KPIs to connected dashboards every 2 s rather than on every reading.
setInterval(() => hub.publishKpis(), 2000);

// `--sim` runs the built-in TypeScript simulator in-process (no Python needed).
if (process.argv.includes('--sim')) {
  const sim = new Simulator(Date.now() % 100000);
  setInterval(() => hub.ingest({ readings: sim.tick() }), 1000);
  console.log('Built-in simulator running (1 batch/s)');
}

app.listen(PORT, () => {
  console.log(`Triage Hub API on http://localhost:${PORT}`);
  console.log(`Ingest: POST /api/ingest with header X-Api-Key: ${INGEST_API_KEY}`);
});
